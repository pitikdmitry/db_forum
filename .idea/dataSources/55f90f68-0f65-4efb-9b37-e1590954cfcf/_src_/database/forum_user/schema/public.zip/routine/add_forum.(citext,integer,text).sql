create function add_forum(p_slug citext, p_user_id integer, p_title text) returns TABLE(forum_id integer, slug citext, user_id integer, title text)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
        INSERT INTO forums (slug, user_id, title)
        VALUES (p_slug, p_user_id, p_title)
        RETURNING forums.forum_id, forums.slug, forums.user_id, forums.title;

END;
$$;
