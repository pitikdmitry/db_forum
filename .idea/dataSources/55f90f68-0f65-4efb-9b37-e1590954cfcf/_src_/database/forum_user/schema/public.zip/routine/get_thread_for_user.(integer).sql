create function get_thread_for_user(p_user_id integer) returns TABLE(thread_id integer, slug citext, forum_id integer, user_id integer, created timestamp with time zone, message text, title text)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY SELECT th.thread_id, th.slug, th.forum_id, th.user_id,
                        th.created, th.message, th.title
    FROM threads th
    WHERE th.user_id = p_user_id;
  END;
$$;
