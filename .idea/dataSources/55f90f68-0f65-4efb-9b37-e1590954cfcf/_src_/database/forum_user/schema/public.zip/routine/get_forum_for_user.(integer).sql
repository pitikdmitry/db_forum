create function get_forum_for_user(p_user_id integer) returns TABLE(forum_id integer, slug citext, user_id integer, title text)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY SELECT f.forum_id, f.slug, f.user_id, f.title
    FROM forums f
    WHERE f.user_id = p_user_id;
  END;
$$;
