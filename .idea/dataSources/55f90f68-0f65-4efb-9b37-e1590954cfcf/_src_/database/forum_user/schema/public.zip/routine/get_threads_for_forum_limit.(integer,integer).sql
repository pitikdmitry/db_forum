create function get_threads_for_forum_limit(p_forum_id integer, p_limit integer) returns TABLE(thread_id integer, slug citext, forum_id integer, user_id integer, created timestamp with time zone, message text, title text)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
        SELECT th.thread_id, th.slug, th.forum_id, th.user_id,
                        th.created, th.message, th.title
        FROM threads th

        WHERE th.forum_id = p_forum_id
        ORDER BY th.created ASC
        LIMIT p_limit;


  END;
$$;
