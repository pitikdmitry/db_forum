create function add_user(p_nickname citext, p_email citext, p_about text, p_fullname text) returns TABLE(user_id integer, nickname citext, email citext, about text, fullname text)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
        INSERT INTO users (nickname, email, about, fullname)
        VALUES (p_nickname, p_email, p_about, p_fullname)
        RETURNING users.user_id, users.nickname, users.email, users.about, users.fullname;
  END;
$$;
