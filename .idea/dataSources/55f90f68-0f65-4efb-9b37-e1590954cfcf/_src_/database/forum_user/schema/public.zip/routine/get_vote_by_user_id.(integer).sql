create function get_vote_by_user_id(p_user_id integer) returns TABLE(vote_id integer, user_id integer, thread_id integer, vote_value text)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY SELECT v.vote_id, v.user_id, v.emathread_idil, v.about, v.fullname
    FROM vote v
    WHERE v.user_id = p_user_id;
  END;
$$;
