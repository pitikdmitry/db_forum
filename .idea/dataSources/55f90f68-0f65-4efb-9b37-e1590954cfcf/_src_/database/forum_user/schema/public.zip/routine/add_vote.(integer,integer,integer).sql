create function add_vote(p_user_id integer, p_thread_id integer, p_vote_value integer) returns TABLE(vote_id integer, user_id integer, thread_id integer, vote_value integer)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
        INSERT INTO vote (user_id, thread_id, vote_value)
        VALUES (p_user_id, p_thread_id, p_vote_value)
        RETURNING vote.vote_id, vote.user_id, vote.thread_id, vote.vote_value;
  END;
$$;
