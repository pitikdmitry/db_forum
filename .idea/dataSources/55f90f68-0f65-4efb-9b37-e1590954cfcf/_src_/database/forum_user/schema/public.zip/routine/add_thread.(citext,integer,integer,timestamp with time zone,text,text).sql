create function add_thread(p_slug citext, p_forum_id integer, p_user_id integer, p_created timestamp with time zone, p_message text, p_title text) returns TABLE(thread_id integer, slug citext, forum_id integer, user_id integer, created timestamp with time zone, message text, title text)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
        INSERT INTO threads (slug, forum_id, user_id, created, message, title)
        VALUES (p_slug, p_forum_id, p_user_id, p_created, p_message, p_title)
        RETURNING threads.thread_id, threads.slug, threads.forum_id, threads.user_id,
                  threads.created, threads.message, threads.title;
  END;
$$;
