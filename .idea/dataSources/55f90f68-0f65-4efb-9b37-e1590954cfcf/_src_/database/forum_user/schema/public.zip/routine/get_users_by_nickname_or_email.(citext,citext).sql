create function get_users_by_nickname_or_email(p_nickname citext, p_email citext) returns TABLE(user_id integer, nickname citext, email citext, about text, fullname text)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY SELECT u.user_id, u.nickname, u.email, u.about, u.fullname
    FROM users u
    WHERE u.nickname = p_nickname or u.email = p_email;
  END;
$$;
