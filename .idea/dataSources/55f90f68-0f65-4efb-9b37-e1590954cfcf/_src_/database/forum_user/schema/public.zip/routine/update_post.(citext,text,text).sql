create function update_post(p_slug citext, p_message text, p_title text) returns void
LANGUAGE plpgsql
AS $$
BEGIN
    UPDATE posts
      SET message = p_message, title = p_title, is_edited = TRUE
      WHERE slug = p_slug;
  END;
$$;
