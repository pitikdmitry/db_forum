create function add_user2(p_nickname citext, p_email citext, p_about text, p_fullname text) returns TABLE(user_id integer)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
        INSERT INTO users (nickname, email, about, fullname)
        VALUES (p_nickname, p_email, p_about, p_fullname)
        RETURNING users.user_id;
  END;
$$;
