create function get_post_by_user_id(p_user_id integer) returns TABLE(thread_id integer, forum_id integer, parent_id integer, user_id integer, created timestamp with time zone, message text, title text)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY SELECT pst.thread_id, pst.slug, pst.forum_id, pst.user_id,
                        pst.created, pst.message, pst.title
    FROM posts pst
    WHERE pst.user_id = p_user_id;
  END;
$$;
