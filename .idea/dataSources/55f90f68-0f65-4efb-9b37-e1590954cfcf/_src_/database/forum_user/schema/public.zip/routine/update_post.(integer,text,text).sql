create function update_post(p_post_id integer, p_message text, p_title text) returns void
LANGUAGE plpgsql
AS $$
BEGIN
    UPDATE posts
      SET message = p_message, title = p_title, is_edited = TRUE
      WHERE post_id = p_post_id;
  END;
$$;
