create function update_user_by_fullname(p_nickname citext, p_fullname text) returns TABLE(user_id integer, nickname citext, email citext, about text, fullname text)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
        UPDATE users
        SET fullname = p_fullname
        WHERE users.nickname = p_nickname
        RETURNING users.user_id, users.nickname, users.email, users.about, users.fullname;
  END;
$$;
