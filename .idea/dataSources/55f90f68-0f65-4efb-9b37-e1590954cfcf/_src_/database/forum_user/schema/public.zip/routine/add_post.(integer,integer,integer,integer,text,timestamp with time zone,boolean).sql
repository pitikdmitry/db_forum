create function add_post(p_thread_id integer, p_forum_id integer, p_user_id integer, p_parent_id integer, p_message text, p_created timestamp with time zone, p_is_edited boolean) returns TABLE(post_id integer, thread_id integer, forum_id integer, user_id integer, parent_id integer, message text, created timestamp with time zone, is_edited boolean)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
        INSERT INTO posts (thread_id, forum_id, user_id, parent_id,
                           message, created, is_edited)

        VALUES (p_thread_id, p_forum_id, p_user_id, p_parent_id,
                p_message, p_created, p_is_edited)

        RETURNING posts.post_id, posts.thread_id, posts.forum_id, posts.user_id,
                  posts.parent_id, posts.message, posts.created, posts.is_edited;
  END;
$$;
